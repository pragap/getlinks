from django.shortcuts import render,redirect
from django.http import JsonResponse
from urllib.parse import urlparse,urljoin
from colorama import Back
import requests
from bs4 import BeautifulSoup
from colorama import init
init()
def home(request):
    if request.method == "POST":
        url=request.POST.get('url')
        if not url.startswith('http'):
            url="http://"+url

        rurl = repr(url)
        response = requests.get(url)
        html_page = BeautifulSoup(response.text, "html.parser")
        all_urls = html_page.findAll("a")
        print(all_urls)
        internal_urls,external_urls = set(),set()
        print(internal_urls)
        domain_name = urlparse(rurl).netloc
        for link in all_urls:
            href=link.get('href')
            
            if href:
                if domain_name in href:    
                    internal_urls.add(href)
                
                elif href[0]=="#":     
                    internal_urls.add(f"{url}{href}")
                    
                else:                      
                    external_urls.add(href)
        internal=list(internal_urls)
        external=list(external_urls)
        return JsonResponse({"internal":internal,"external":external})
        
    return render(request,'home.html')